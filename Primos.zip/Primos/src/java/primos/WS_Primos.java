/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package primos;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author AMANDA
 */
@WebService(serviceName = "WS_Primos")
public class WS_Primos {

    @WebMethod(operationName = "primo")
    public String primos(@WebParam(name = "primo") int n) {
        
        int i = 2;
        
        while (i < n) {
            if (n % i == 0){
                return "Nao eh primo " + n + " !";
        }
        i++;
     }
        return "Eh primo " + n + " !";
        
    }
}

